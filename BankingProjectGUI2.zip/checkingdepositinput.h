#ifndef CHECKINGDEPOSITINPUT_H
#define CHECKINGDEPOSITINPUT_H

#include <QDialog>

namespace Ui {
class CheckingDepositInput;
}

class CheckingDepositInput : public QDialog
{
    Q_OBJECT

public:
    explicit CheckingDepositInput(QWidget *parent = 0);
    ~CheckingDepositInput();

private:
    Ui::CheckingDepositInput *ui;
};

#endif // CHECKINGDEPOSITINPUT_H
