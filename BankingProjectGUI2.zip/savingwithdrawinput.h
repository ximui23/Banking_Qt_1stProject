#ifndef SAVINGWITHDRAWINPUT_H
#define SAVINGWITHDRAWINPUT_H

#include <QDialog>

namespace Ui {
class SavingWithdrawInput;
}

class SavingWithdrawInput : public QDialog
{
    Q_OBJECT

public:
    explicit SavingWithdrawInput(QWidget *parent = 0);
    ~SavingWithdrawInput();

private:
    Ui::SavingWithdrawInput *ui;
    SavingWithdrawInput *s_w_Input;
};

#endif // SAVINGWITHDRAWINPUT_H
