#include "withdrawwindow.h"
#include <QtWidgets>

WithdrawWindow::WithdrawWindow(QWidget *parent) : QWidget(parent)
{
    QGridLayout *grid = new QGridLayout;
    grid->addWidget(createActions(),0,0);

    setLayout(grid);

    setMinimumSize(350,200);

    setWindowTitle(tr("Withdraw Window"));
}

QGroupBox *WithdrawWindow::createActions()
{
    QGroupBox *groupBox = new QGroupBox(tr("Withdraw"));
    QPushButton *savingButton = new QPushButton(tr("Saving Account"));
    QPushButton *checkingButton = new QPushButton(tr("Checking Account"));

    QObject::connect(savingButton, SIGNAL (clicked()),this, SLOT (Saving_Withdraw()));
    QObject::connect(checkingButton, SIGNAL (clicked()),this, SLOT (Checking_Withdraw()));

    QVBoxLayout *vbox = new QVBoxLayout;
    vbox->addWidget(savingButton);
    vbox->addWidget(checkingButton);
    groupBox->setLayout(vbox);

    return groupBox;
}

//void WithdrawWindow::Saving_Withdraw()
//{
//    Sav_Wit_Amount *sWitInput = new Sav_Wit_Amount();
//    sWitInput->show();
//}

//void WithdrawWindow::Checking_Withdraw()
//{
//    Che_Wit_Amount *cWitInput = new Che_Wit_Amount();
//    cWitInput->show();
//}

void WithdrawWindow::Saving_Withdraw()
{
    bool ok;
    double d  = QInputDialog::getDouble(this, tr("Withdraw From Saving"),
                                        tr("Amount: "), 23.89, -10000, 10000, 2, &ok);
    if(ok)
        label->setText(QString("$%1").arg(d));
}

void WithdrawWindow::Checking_Withdraw()
{
    bool ok;
    double d1  = QInputDialog::getDouble(this, tr("Withdraw From Checking"),
                                        tr("Amount: "), 14.34, -10000, 10000, 2, &ok);
    if(ok)
        label1->setText(QString("$%1").arg(d1));
}
