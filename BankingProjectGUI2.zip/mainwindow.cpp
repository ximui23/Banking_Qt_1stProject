#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    checkingDialog = new CheckingDialog(this);
    checkingDialog->show();
}

void MainWindow::on_pushButton_2_clicked()
{
    savingDialog = new SavingDialog(this);
    savingDialog->show();
}

void MainWindow::on_pushButton_3_clicked()
{
    depositDialog = new DepositDialog(this);
    depositDialog->show();
}

void MainWindow::on_pushButton_4_clicked()
{
    withdrawDialog = new WithdrawDialog(this);
    withdrawDialog->show();
}

void MainWindow::on_pushButton_5_clicked()
{
    transferDialog = new TransferDialog(this);
    transferDialog->show();
}

void MainWindow::on_pushButton_6_clicked()
{
    historyDialog = new HistoryDialog(this);
    historyDialog->show();
}
