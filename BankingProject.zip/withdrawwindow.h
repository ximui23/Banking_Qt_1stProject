#ifndef WITHDRAWWINDOW_H
#define WITHDRAWWINDOW_H

#include <QWidget>
class QGroupBox;

class WithdrawWindow : public QWidget
{
    Q_OBJECT
public:
    explicit WithdrawWindow(QWidget *parent = nullptr);

signals:

public slots:

private:
    QGroupBox *createActions();

    QGroupBox *groupbox;
};

#endif // WITHDRAWWINDOW_H
