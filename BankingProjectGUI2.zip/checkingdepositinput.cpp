#include "checkingdepositinput.h"
#include "ui_checkingdepositinput.h"

CheckingDepositInput::CheckingDepositInput(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CheckingDepositInput)
{
    ui->setupUi(this);
}

CheckingDepositInput::~CheckingDepositInput()
{
    delete ui;
}
