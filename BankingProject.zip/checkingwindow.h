#ifndef CHECKINGWINDOW_H
#define CHECKINGWINDOW_H

#include <QWidget>

class QGroupBox;

class CheckingWindow : public QWidget
{
    Q_OBJECT
public:
    explicit CheckingWindow(QWidget *parent = nullptr);

signals:

public slots:

private:
    QGroupBox *groupBox;

    QGroupBox *createCheckingInfo();
};

#endif // CHECKINGWINDOW_H
