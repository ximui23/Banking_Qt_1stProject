#include "depositwindow.h"
#include <QtWidgets>

DepositWindow::DepositWindow(QWidget *parent) : QWidget(parent)
{
    QGridLayout *grid = new QGridLayout;
    grid->addWidget(createActions(), 0, 0);

        setLayout(grid);

        setWindowTitle(tr("Deposit"));
        resize(400, 220);
    }
QGroupBox *DepositWindow::createActions()
{
    QGroupBox *groupBox = new QGroupBox(tr("Deposit"));
    QPushButton *savingButton = new QPushButton(tr("Saving Account"));
    QPushButton *checkingButton = new QPushButton(tr("Checking Account"));

    QVBoxLayout *vbox = new QVBoxLayout;
    vbox->addWidget(savingButton);
    vbox->addWidget(checkingButton);
    groupBox->setLayout(vbox);

    return groupBox;
}
