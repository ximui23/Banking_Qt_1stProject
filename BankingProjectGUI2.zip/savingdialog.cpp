#include "savingdialog.h"
#include "ui_savingdialog.h"

SavingDialog::SavingDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SavingDialog)
{
    ui->setupUi(this);
}

SavingDialog::~SavingDialog()
{
    delete ui;
}
