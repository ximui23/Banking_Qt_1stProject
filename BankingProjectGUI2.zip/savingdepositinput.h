#ifndef SAVINGDEPOSITINPUT_H
#define SAVINGDEPOSITINPUT_H

#include <QDialog>

namespace Ui {
class SavingDepositInput;
}

class SavingDepositInput : public QDialog
{
    Q_OBJECT

public:
    explicit SavingDepositInput(QWidget *parent = 0);
    ~SavingDepositInput();

private:
    Ui::SavingDepositInput *ui;
};

#endif // SAVINGDEPOSITINPUT_H
