#ifndef WITHDRAWWINDOW_H
#define WITHDRAWWINDOW_H

#include <QWidget>


class QGroupBox;
class QLabel;

class WithdrawWindow : public QWidget
{
    Q_OBJECT
public:
    explicit WithdrawWindow(QWidget *parent = nullptr);

signals:

private slots:
    void Saving_Withdraw();
    void Checking_Withdraw();

private:
    QGroupBox *createActions();
    QGroupBox *groupBox;

//    Sav_Wit_Amount *sWitInput;
//    Che_Wit_Amount *cWitInput;

    QLabel *label;
    QLabel *label1;

};

#endif // WITHDRAWWINDOW_H
