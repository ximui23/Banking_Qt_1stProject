#ifndef SAVINGWINDOW_H
#define SAVINGWINDOW_H

#include <QWidget>


class QGroupBox;

class SavingWindow : public QWidget
{
    Q_OBJECT
public:
    explicit SavingWindow(QWidget *parent = nullptr);

signals:

public slots:

private:

    QGroupBox *groupBox;

    QGroupBox *createSavingInfo();

};

#endif // SAVINGWINDOW_H
