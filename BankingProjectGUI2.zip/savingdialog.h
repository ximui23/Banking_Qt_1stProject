#ifndef SAVINGDIALOG_H
#define SAVINGDIALOG_H

#include <QDialog>

namespace Ui {
class SavingDialog;
}

class SavingDialog : public QDialog
{
    Q_OBJECT

public:
    explicit SavingDialog(QWidget *parent = 0);
    ~SavingDialog();

private:
    Ui::SavingDialog *ui;
};

#endif // SAVINGDIALOG_H
