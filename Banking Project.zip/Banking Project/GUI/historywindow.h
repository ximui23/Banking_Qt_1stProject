#ifndef HISTORYWINDOW_H
#define HISTORYWINDOW_H

#include <QWidget>

class HistoryWindow : public QWidget
{
    Q_OBJECT
public:
    explicit HistoryWindow(QWidget *parent = nullptr);

signals:

public slots:
};

#endif // HISTORYWINDOW_H