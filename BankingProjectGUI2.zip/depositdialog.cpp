#include "depositdialog.h"
#include "ui_depositdialog.h"

DepositDialog::DepositDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DepositDialog)
{
    ui->setupUi(this);
}

DepositDialog::~DepositDialog()
{
    delete ui;
}

void DepositDialog::on_pushButton_clicked()
{
    s_depositInput = new SavingDepositInput(this);
    s_depositInput->show();
}

void DepositDialog::on_pushButton_2_clicked()
{
    c_depositInput = new CheckingDepositInput(this);
    c_depositInput->show();
}
