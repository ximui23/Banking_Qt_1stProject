#ifndef DEPOSITWINDOW_H
#define DEPOSITWINDOW_H

#include <QWidget>


class QGroupBox;
class QLabel;


class DepositWindow : public QWidget
{
    Q_OBJECT
public:
    explicit DepositWindow(QWidget *parent = nullptr);

signals:

private slots:
    void Saving_Deposit();
    void Checking_Deposit();

private:
    QGroupBox *createActions();
    QGroupBox *groupBox;


    QLabel *doubleLabel;
    QLabel *doubleLabel1;

};

#endif // DEPOSITWINDOW_H
