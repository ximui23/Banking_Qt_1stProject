#ifndef WINDOW_H
#define WINDOW_H

#include <QWidget>
#include "savingwindow.h"
#include "checkingwindow.h"
#include "depositwindow.h"
#include "withdrawwindow.h"
#include "transferwindow.h"


class QGroupBox;

class window : public QWidget
{
    Q_OBJECT
public:
    explicit window(QWidget *parent = nullptr);


signals:

public slots:

private slots:
    void handleSaving();
    void handleChecking();
    void handleDeposit();
    void handleWithdraw();
    void handleTransfer();

private:
    QGroupBox *createAccountInfo();
    QGroupBox *createAccountSelector();
    QGroupBox *createAccountActions();

    SavingWindow *savingWindow;
    CheckingWindow *checkingWindow;
    DepositWindow *dWindow;
    WithdrawWindow *withdrawWindow;
    TransferWindow *tWindow;
};

#endif // WINDOW_H
