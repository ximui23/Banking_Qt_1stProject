#include "window.h"
#include<QtWidgets>
#include<QtGui>

window::window(QWidget *parent) : QWidget(parent)
{
    QGridLayout *grid = new QGridLayout;
        grid->addWidget(createAccountInfo(), 0, 0);
        grid->addWidget(createAccountSelector(), 1, 0);
        grid->addWidget(createAccountActions(), 2, 0);
        setLayout(grid);

        setWindowTitle(tr("Banking"));
        setMinimumSize(700,620);
        resize(480, 320);

    }
QGroupBox *window::createAccountInfo()
    {
        QGroupBox *groupBox = new QGroupBox(tr("Account Information"));

        QLabel *label1 = new QLabel("UserName ");
        QLabel *label2 = new QLabel("AccountNumber: ");
        QLabel *label3 = new QLabel("Selected Account Balance: ");

        QVBoxLayout *vbox = new QVBoxLayout;
        vbox->addWidget(label1);
        vbox->addWidget(label2);
        vbox->addWidget(label3);
        vbox->addStretch(1);
        groupBox->setLayout(vbox);

        return groupBox;

    }

QGroupBox *window::createAccountSelector()
    {
        QGroupBox *groupBox = new QGroupBox(tr("Select Account Type"));

        QPushButton *saving = new QPushButton(tr("Saving"));
        QPushButton *checking = new QPushButton(tr("Checking"));

        //connect button signal to appropriate slot
        QObject::connect(saving, SIGNAL (released()),this, SLOT (handleSaving()));
        QObject::connect(checking, SIGNAL (released()),this, SLOT (handleChecking()));

        QVBoxLayout *vbox = new QVBoxLayout;
        vbox->addWidget(saving);
        vbox->addWidget(checking);
        vbox->addStretch(1);
        groupBox->setLayout(vbox);

        return groupBox;
    }

QGroupBox *window::createAccountActions()
    {
        QGroupBox *groupBox = new QGroupBox(tr("Transaction/History"));

        QPushButton *deposit = new QPushButton(tr("Deposit"));
        QPushButton *withdraw = new QPushButton(tr("Withdraw"));
        QPushButton *transfer = new QPushButton(tr("Transfer"));
        QPushButton *history = new QPushButton(tr("History"));

        //connect button
        QObject::connect(deposit, SIGNAL (released()),this, SLOT (handleDeposit()));
        QObject::connect(withdraw, SIGNAL (released()),this, SLOT (handleWithdraw()));
        QObject::connect(transfer, SIGNAL (released()),this, SLOT (handleTransfer()));

        QVBoxLayout *vbox = new QVBoxLayout;

        vbox->addWidget(deposit);
        vbox->addWidget(withdraw);
        vbox->addWidget(transfer);
        vbox->addWidget(history);
        vbox->addStretch(1);
        groupBox->setLayout(vbox);
        return groupBox;

    }

void window::handleSaving()
{
    SavingWindow *savingWindow = new SavingWindow();
    savingWindow->show();
}

void window::handleChecking()
{
    CheckingWindow *checkingWindow = new CheckingWindow();
    checkingWindow->show();
}

void window::handleDeposit()
{
    DepositWindow *dWindow = new DepositWindow();
    dWindow->show();
}

void window::handleWithdraw()
{
    WithdrawWindow *withdrawWindow = new WithdrawWindow();
    withdrawWindow->show();
}

void window::handleTransfer()
{
    TransferWindow *tWindow = new TransferWindow();
    tWindow->show();
}
