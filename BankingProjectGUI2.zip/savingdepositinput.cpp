#include "savingdepositinput.h"
#include "ui_savingdepositinput.h"

SavingDepositInput::SavingDepositInput(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SavingDepositInput)
{
    ui->setupUi(this);
}

SavingDepositInput::~SavingDepositInput()
{
    delete ui;
}
