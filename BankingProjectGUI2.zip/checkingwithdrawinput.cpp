#include "checkingwithdrawinput.h"
#include "ui_checkingwithdrawinput.h"

CheckingWithdrawInput::CheckingWithdrawInput(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CheckingWithdrawInput)
{
    ui->setupUi(this);
}

CheckingWithdrawInput::~CheckingWithdrawInput()
{
    delete ui;
}
