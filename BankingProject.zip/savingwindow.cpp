#include "savingwindow.h"
#include<QtWidgets>

SavingWindow::SavingWindow(QWidget *parent) : QWidget(parent)
{
    QGridLayout *grid = new QGridLayout;
    grid->addWidget(createSavingInfo(), 0, 0);

        setLayout(grid);

        setWindowTitle(tr("Saving Account"));
        resize(480, 320);
    }
    QGroupBox *SavingWindow::createSavingInfo()
    {
        QGroupBox *groupBox = new QGroupBox(tr("Saving Account's Information"));

        QLabel *label1 = new QLabel("Saving Account's Number ");
        QLabel *label2 = new QLabel("Saving Account's Balance: ");

        QVBoxLayout *vbox = new QVBoxLayout;
        vbox->addWidget(label1);
        vbox->addWidget(label2);

        groupBox->setLayout(vbox);

        return groupBox;

    }
