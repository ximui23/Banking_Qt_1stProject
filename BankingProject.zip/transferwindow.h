#ifndef TRANSFERWINDOW_H
#define TRANSFERWINDOW_H

#include <QWidget>
class QGroupBox;
class QLabel;
class QPushButton;
class QDialogButtonBox;

class TransferWindow : public QWidget
{
    Q_OBJECT
public:
    explicit TransferWindow(QWidget *parent = nullptr);

signals:

public slots:

private:
//    QLabel *label;
//    QLabel *label1;
    QPushButton *button;
    QPushButton *button1;
    QPushButton *button2;
    QPushButton *button3;
    QGroupBox *transferFrom;
    QGroupBox *transferTo;
    QGroupBox *amount;
    QDialogButtonBox *buttonBox;


    void createTransferAction();
};

#endif // TRANSFERWINDOW_H
