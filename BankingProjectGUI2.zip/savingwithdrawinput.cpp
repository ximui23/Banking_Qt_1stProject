#include "savingwithdrawinput.h"
#include "ui_savingwithdrawinput.h"

SavingWithdrawInput::SavingWithdrawInput(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SavingWithdrawInput)
{
    ui->setupUi(this);
}

SavingWithdrawInput::~SavingWithdrawInput()
{
    delete ui;
}
