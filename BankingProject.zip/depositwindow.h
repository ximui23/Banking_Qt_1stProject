#ifndef DEPOSITWINDOW_H
#define DEPOSITWINDOW_H

#include <QWidget>

class QGroupBox;

class DepositWindow : public QWidget
{
    Q_OBJECT
public:
    explicit DepositWindow(QWidget *parent = nullptr);

signals:

public slots:

private:
    QGroupBox *createActions();

    QGroupBox *groupbox;
};

#endif // DEPOSITWINDOW_H
