#ifndef DEPOSITDIALOG_H
#define DEPOSITDIALOG_H

#include <QDialog>
#include "savingdepositinput.h"
#include "checkingdepositinput.h"

namespace Ui {
class DepositDialog;
}

class DepositDialog : public QDialog
{
    Q_OBJECT

public:
    explicit DepositDialog(QWidget *parent = 0);
    ~DepositDialog();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::DepositDialog *ui;
    SavingDepositInput *s_depositInput;
    CheckingDepositInput *c_depositInput;
};

#endif // DEPOSITDIALOG_H
