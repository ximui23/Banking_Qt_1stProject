#include "withdrawdialog.h"
#include "ui_withdrawdialog.h"

WithdrawDialog::WithdrawDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::WithdrawDialog)
{
    ui->setupUi(this);
}

WithdrawDialog::~WithdrawDialog()
{
    delete ui;
}

void WithdrawDialog::on_pushButton_clicked()
{
    s_w_Input = new SavingWithdrawInput(this);
    s_w_Input->show();
}

void WithdrawDialog::on_pushButton_2_clicked()
{
    c_w_Input = new CheckingWithdrawInput(this);
    c_w_Input->show();
}
