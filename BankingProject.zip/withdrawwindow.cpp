#include "withdrawwindow.h"
#include <QtWidgets>

WithdrawWindow::WithdrawWindow(QWidget *parent) : QWidget(parent)
{
    QGridLayout *grid = new QGridLayout;
    grid->addWidget(createActions(), 0, 0);

        setLayout(grid);

        setWindowTitle(tr("Withdraw"));
        resize(400, 220);
    }
QGroupBox *WithdrawWindow::createActions()
{
    QGroupBox *groupBox = new QGroupBox(tr("Withdraw"));
    QPushButton *savingButton = new QPushButton(tr("Saving Account"));
    QPushButton *checkingButton = new QPushButton(tr("Checking Account"));

    QVBoxLayout *vbox = new QVBoxLayout;
    vbox->addWidget(savingButton);
    vbox->addWidget(checkingButton);
    groupBox->setLayout(vbox);

    return groupBox;
}
