#include "checkingwindow.h"
#include <QtWidgets>

CheckingWindow::CheckingWindow(QWidget *parent) : QWidget(parent)
{
    QGridLayout *grid = new QGridLayout;
    grid->addWidget(createCheckingInfo(), 0, 0);

        setLayout(grid);

        setWindowTitle(tr("Checking Account"));
        resize(480, 320);
    }
    QGroupBox *CheckingWindow::createCheckingInfo()
    {
        QGroupBox *groupBox = new QGroupBox(tr("Checking Account's Information"));

        QLabel *label1 = new QLabel("Checking Account's Number ");
        QLabel *label2 = new QLabel("Checking Account's Balance: ");

        QVBoxLayout *vbox = new QVBoxLayout;
        vbox->addWidget(label1);
        vbox->addWidget(label2);

        groupBox->setLayout(vbox);

        return groupBox;

}
