#ifndef WITHDRAWDIALOG_H
#define WITHDRAWDIALOG_H

#include <QDialog>
#include "savingwithdrawinput.h"
#include "checkingwithdrawinput.h"

namespace Ui {
class WithdrawDialog;
}

class WithdrawDialog : public QDialog
{
    Q_OBJECT

public:
    explicit WithdrawDialog(QWidget *parent = 0);
    ~WithdrawDialog();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::WithdrawDialog *ui;
    SavingWithdrawInput *s_w_Input;
    CheckingWithdrawInput *c_w_Input;
};

#endif // WITHDRAWDIALOG_H
