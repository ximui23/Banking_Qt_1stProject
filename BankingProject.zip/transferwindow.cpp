#include "transferwindow.h"
#include <QtWidgets>

TransferWindow::TransferWindow(QWidget *parent) : QWidget(parent)
{
    createTransferAction();

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout->addWidget(transferFrom);
    mainLayout->addWidget(transferTo);
//    QGridLayout *grid = new QGridLayout;
//    grid->addWidget(createTransferAction(), 0, 0);
    setLayout(mainLayout);

    setWindowTitle(tr("Transfer"));

    setMinimumSize(440,380);
}

void TransferWindow::createTransferAction()
{
    transferFrom = new QGroupBox(tr("Transfer From:"));
    QHBoxLayout *layout = new QHBoxLayout;


   //label = new QLabel("Transfer From: ");
    //label1 = new QLabel("Transfer To: ");
   button = new QPushButton(tr("Checking"));
   button1 = new QPushButton(tr("Saving"));

   //layout->addWidget(label);
   layout->addWidget(button);
   layout->addWidget(button1);

   transferTo = new QGroupBox(tr("Transfer To: "));
   QHBoxLayout *layout1 = new QHBoxLayout;
   //label1 = new QLabel("Transfer To: ");
   button2 = new QPushButton(tr("Checking"));
   button3 = new QPushButton(tr("Saving"));

    //layout1->addWidget(label1);
    layout1->addWidget(button2);
    layout1->addWidget(button3);


    transferFrom->setLayout(layout);
    transferTo->setLayout(layout1);

    amount = new QGroupBox(tr("Amount: "));

//    buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel);

//    connect(buttonBox, &QDialogButtonBox::accepted, this, &QDialog::accept);
//    connect(buttonBox, &QDialogButtonBox::rejected, this, &QDialog::reject);

}
