#ifndef CHECKINGWITHDRAWINPUT_H
#define CHECKINGWITHDRAWINPUT_H

#include <QDialog>

namespace Ui {
class CheckingWithdrawInput;
}

class CheckingWithdrawInput : public QDialog
{
    Q_OBJECT

public:
    explicit CheckingWithdrawInput(QWidget *parent = 0);
    ~CheckingWithdrawInput();

private:
    Ui::CheckingWithdrawInput *ui;
};

#endif // CHECKINGWITHDRAWINPUT_H
